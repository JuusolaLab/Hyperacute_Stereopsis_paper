from .marker import main
main()
