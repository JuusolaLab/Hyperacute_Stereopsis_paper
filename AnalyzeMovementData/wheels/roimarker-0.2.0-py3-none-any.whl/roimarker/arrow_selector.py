# ArrowSelector moved to tk_steroid's matplotlib module
from tk_steroids.matplotlib import ArrowSelector
