'''
Beware!
Everything imported here may become a menu item or a cli argument.
'''

from .compare_opticflow import error_at_flight, complete_flow_analysis
from .illustrate_experiments import illustrate_experiments

